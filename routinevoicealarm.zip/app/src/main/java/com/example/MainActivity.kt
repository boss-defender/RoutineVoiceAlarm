package com.example

import android.Manifest
import android.app.AlarmManager
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.alarm.RoutineVoiceService
import com.example.alarm.VoiceAlarmState
import com.example.data.Routine
import com.example.ui.RoutineViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var localTts: TextToSpeech? = null
    private var isTtsReady = false

    private val isExactAlarmGranted = mutableStateOf(false)
    private val isOverlayGranted = mutableStateOf(false)
    private val isBatteryOptIgnored = mutableStateOf(false)
    private val isNotificationPolicyGranted = mutableStateOf(false)
    private val isPostNotificationGranted = mutableStateOf(false)

    override fun onResume() {
        super.onResume()
        checkAllPermissions()
    }

    private fun checkAllPermissions() {
        isExactAlarmGranted.value = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }

        isOverlayGranted.value = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        isBatteryOptIgnored.value = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            pm?.isIgnoringBatteryOptimizations(packageName) ?: true
        } else {
            true
        }

        isNotificationPolicyGranted.value = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
            nm?.isNotificationPolicyAccessGranted ?: true
        } else {
            true
        }

        isPostNotificationGranted.value = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
                Toast.makeText(this, "Grant EXACT ALARM timing permission", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                try {
                    val intent = Intent(Settings.ACTION_SETTINGS)
                    startActivity(intent)
                } catch (ex: Exception) {
                    Toast.makeText(this, "Please search settings for Exact Alarms", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Exact Alarm is active by default ✓", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
                Toast.makeText(this, "Enable Draw Over Other Apps/Overlay in settings", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Failed to open settings overlay permission", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Overlay is active by default ✓", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestBatteryOptimizationsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
                Toast.makeText(this, "Bypass battery saving mode", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                try {
                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    startActivity(intent)
                } catch (ex: Exception) {
                    Toast.makeText(this, "Please locate Battery Optimization in Settings", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Battery saving bypass active by default ✓", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestNotificationPolicyPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                startActivity(intent)
                Toast.makeText(this, "Enable Do Not Disturb Bypass in Settings", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Failed to open notification settings page", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Policy permission is active by default ✓", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Critical Fix: Configure standard lock screen wakeup and screen-on capabilities
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            keyguardManager?.requestDismissKeyguard(this, null)
        }

        handleAlarmIntent(intent)
        enableEdgeToEdge()
        localTts = TextToSpeech(this, this)

        setContent {
            val context = LocalContext.current
            val sharedPref = remember { context.getSharedPreferences("routine_app_prefs", Context.MODE_PRIVATE) }
            var isDarkTheme by remember { mutableStateOf(sharedPref.getBoolean("dark_theme_enabled", true)) }

            val activeAlarmTitle by VoiceAlarmState.activeAlarmTitle.collectAsStateWithLifecycle()

            // Foreground-executed high priority TTS loop with max volume config
            LaunchedEffect(activeAlarmTitle) {
                val title = activeAlarmTitle
                if (title != null) {
                    val startTime = System.currentTimeMillis()
                    val threeMinutesMs = 3 * 60 * 1000
                    
                    val audioManager = getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
                    var originalVolume = -1
                    try {
                        audioManager?.let { am ->
                            originalVolume = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                            val maxVol = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                            am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, maxVol, 0)
                        }
                    } catch (e: Exception) {
                        Log.e("MainActivity", "Failed to scale volume to max on Alarm loop", e)
                    }

                    try {
                        while (isActive && (System.currentTimeMillis() - startTime) < threeMinutesMs) {
                            val hasBangla = title.any { it in '\u0980'..'\u09FF' }
                            val locale = if (hasBangla) Locale("bn", "BD") else Locale.US
                            
                            val speechEngine = localTts
                            if (speechEngine != null && isTtsReady) {
                                val result = speechEngine.setLanguage(locale)
                                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                                    if (hasBangla) {
                                        speechEngine.language = Locale("bn", "IN")
                                    } else {
                                        speechEngine.language = Locale.US
                                    }
                                } else {
                                    speechEngine.language = locale
                                }
                                speechEngine.setPitch(1.0f)
                                speechEngine.setSpeechRate(0.85f)
                                
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    val voices = speechEngine.voices
                                    if (!voices.isNullOrEmpty()) {
                                        val matchingSorted = voices.filter { voice ->
                                            val voiceLocale = voice.locale
                                            voiceLocale.language == locale.language
                                        }.sortedByDescending { voice ->
                                            val nameLower = voice.name.lowercase(Locale.ROOT)
                                            var score = 0
                                            if (nameLower.contains("male") || nameLower.contains("-male") || nameLower.contains("man")) score += 20
                                            if (nameLower.contains("-m-") || nameLower.contains("_m_") || nameLower.endsWith("-m")) score += 15
                                            if (locale.language == "bn") {
                                                if (nameLower.contains("bdb") || nameLower.contains("bam")) score += 15
                                            }
                                            if (!voice.isNetworkConnectionRequired) score += 2
                                            score
                                        }
                                        val selectedVoice = matchingSorted.firstOrNull()
                                        if (selectedVoice != null) {
                                            speechEngine.voice = selectedVoice
                                        }
                                    }
                                }

                                val utteranceId = "alarm_ut_${System.currentTimeMillis()}"
                                val bundle = Bundle().apply {
                                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
                                }
                                speechEngine.speak(title, TextToSpeech.QUEUE_FLUSH, bundle, utteranceId)
                            }
                            
                            delay(250)
                            while (localTts?.isSpeaking == true && isActive) {
                                delay(50)
                            }
                            // Pause exactly 0.7 seconds between vocal announcements
                            delay(700)
                        }
                    } catch (e: Exception) {
                        Log.e("MainActivity", "Speech looping exception", e)
                    } finally {
                        if (originalVolume != -1) {
                            try {
                                audioManager?.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, originalVolume, 0)
                            } catch (e: Exception) {
                                Log.e("MainActivity", "Could not restore volume", e)
                            }
                        }
                    }
                } else {
                    localTts?.stop()
                }
            }

            val notifyLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { granted ->
                isPostNotificationGranted.value = granted
                if (!granted) {
                    Toast.makeText(context, "Notifications are required to show alarms.", Toast.LENGTH_LONG).show()
                }
            }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color.Transparent
                ) { innerPadding ->
                    RoutineVoiceDashboard(
                        modifier = Modifier.padding(innerPadding),
                        isDarkTheme = isDarkTheme,
                        onThemeToggle = {
                            isDarkTheme = !isDarkTheme
                            sharedPref.edit().putBoolean("dark_theme_enabled", isDarkTheme).apply()
                        },
                        onSpeakTest = { title -> testSpeak(title) },
                        isExactAlarmGranted = isExactAlarmGranted.value,
                        isOverlayGranted = isOverlayGranted.value,
                        isBatteryOptIgnored = isBatteryOptIgnored.value,
                        isNotificationPolicyGranted = isNotificationPolicyGranted.value,
                        isPostNotificationGranted = isPostNotificationGranted.value,
                        onRequestExactAlarm = { requestExactAlarmPermission() },
                        onRequestOverlay = { requestOverlayPermission() },
                        onRequestBatteryOpt = { requestBatteryOptimizationsPermission() },
                        onRequestNotificationPolicy = { requestNotificationPolicyPermission() },
                        onRequestPostNotifications = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notifyLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                Toast.makeText(context, "Notifications are active on this device.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAlarmIntent(intent)
        
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            keyguardManager?.requestDismissKeyguard(this, null)
        }
    }

    private fun handleAlarmIntent(intent: Intent?) {
        if (intent != null && intent.getBooleanExtra("ALARM_TRIGGERED", false)) {
            val title = intent.getStringExtra("ROUTINE_TITLE") ?: "Routine Reminder"
            Log.d("MainActivity", "Alarm triggered via intent extra: $title")
            VoiceAlarmState.activeAlarmTitle.value = title
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            Log.d("MainActivity", "Local TTS service initialized")
            isTtsReady = true
        } else {
            Log.e("MainActivity", "Local TTS service initialization failed")
        }
    }

    private fun testSpeak(title: String) {
        val speechEngine = localTts
        if (speechEngine == null || !isTtsReady) {
            Toast.makeText(this, "Speech engine initializing...", Toast.LENGTH_SHORT).show()
            return
        }

        val hasBangla = title.any { it in '\u0980'..'\u09FF' }
        val locale = if (hasBangla) {
            Locale("bn", "BD")
        } else {
            Locale.US
        }

        try {
            val result = speechEngine.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                if (hasBangla) {
                    speechEngine.language = Locale("bn", "IN")
                } else {
                    speechEngine.language = Locale.US
                }
            } else {
                speechEngine.language = locale
            }

            speechEngine.setPitch(1.0f)
            speechEngine.setSpeechRate(0.85f)

            // Select best available Male Voice matching our language
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val voices = speechEngine.voices
                if (!voices.isNullOrEmpty()) {
                    val matchingSorted = voices.filter { voice ->
                        val voiceLocale = voice.locale
                        voiceLocale.language == locale.language
                    }.sortedByDescending { voice ->
                        val nameLower = voice.name.lowercase(Locale.ROOT)
                        var score = 0
                        if (nameLower.contains("male") || nameLower.contains("-male") || nameLower.contains("man")) score += 20
                        if (nameLower.contains("-m-") || nameLower.contains("_m_") || nameLower.endsWith("-m")) score += 15
                        if (locale.language == "bn") {
                            if (nameLower.contains("bdb") || nameLower.contains("bam")) score += 15
                        }
                        if (!voice.isNetworkConnectionRequired) score += 2
                        score
                    }
                    val selectedVoice = matchingSorted.firstOrNull()
                    if (selectedVoice != null) {
                        speechEngine.voice = selectedVoice
                    }
                }
            }

            speechEngine.speak(title, TextToSpeech.QUEUE_FLUSH, null, "PreviewID")
            Toast.makeText(this, "Speaking preview: \"$title\" 🔊", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e("MainActivity", "Speaking preview error", e)
        }
    }

    private fun checkAndRequestAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!alarmManager.canScheduleExactAlarms()) {
                val intent = Intent().apply {
                    action = Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM
                    data = Uri.fromParts("package", packageName, null)
                }
                startActivity(intent)
                Toast.makeText(this, "Please grant active permission to schedule exact system alarms.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Exact alarm permission is active! ✓", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Exact alarms are active by default.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        localTts?.apply {
            stop()
            shutdown()
        }
        super.onDestroy()
    }
}

@Composable
fun ThemeToggleIcon(isDark: Boolean, modifier: Modifier = Modifier) {
    val animateFactor by animateFloatAsState(
        targetValue = if (isDark) 1f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "sun_moon_transition"
    )

    Canvas(modifier = modifier) {
        val sizePx = size.minDimension
        val center = Offset(size.width / 2, size.height / 2)
        val radius = sizePx * 0.45f
        
        val currentColor = androidx.compose.ui.graphics.lerp(
            Color(0xFFF59E0B), 
            Color(0xFF00F0FF), 
            animateFactor
        )

        if (animateFactor >= 0.5f) {
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(center.x - radius * 0.2f, center.y - radius)
                quadraticTo(
                    center.x + radius * 1.1f, center.y,
                    center.x - radius * 0.2f, center.y + radius
                )
                quadraticTo(
                    center.x + radius * 0.3f, center.y,
                    center.x - radius * 0.2f, center.y - radius
                )
                close()
            }
            drawPath(
                path = path,
                color = currentColor
            )
        } else {
            drawCircle(
                color = currentColor,
                radius = radius * 0.55f,
                center = center
            )
            val rayCount = 8
            val innerRayRad = radius * 0.70f
            val outerRayRad = radius * 1.05f
            val rayAlpha = 1f - (animateFactor * 2f).coerceAtMost(1f)
            
            for (i in 0 until rayCount) {
                val angle = (i * 2 * Math.PI / rayCount) + (animateFactor * Math.PI / 4)
                val cosVal = kotlin.math.cos(angle).toFloat()
                val sinVal = kotlin.math.sin(angle).toFloat()
                val start = Offset(
                    center.x + innerRayRad * cosVal,
                    center.y + innerRayRad * sinVal
                )
                val end = Offset(
                    center.x + outerRayRad * cosVal,
                    center.y + outerRayRad * sinVal
                )
                drawLine(
                    color = Color(0xFFF59E0B).copy(alpha = rayAlpha),
                    start = start,
                    end = end,
                    strokeWidth = 3f,
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            }
        }
    }
}

// Extension functions for sleek glass style
@Composable
fun Modifier.glassCard(isDarkTheme: Boolean, shape: RoundedCornerShape): Modifier = this
    .clip(shape)
    .background(
        if (isDarkTheme) {
            Color(0x24121226) // Frost Dark obsidian tint
        } else {
            Color(0x80FFFFFF) // Frost Light pearl tint
        }
    )
    .border(
        BorderStroke(
            width = 1.dp,
            brush = Brush.linearGradient(
                colors = if (isDarkTheme) {
                    listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.04f))
                } else {
                    listOf(Color.White.copy(alpha = 0.75f), Color.White.copy(alpha = 0.20f))
                }
            )
        ),
        shape = shape
    )

@Composable
fun RoutineVoiceDashboard(
    modifier: Modifier = Modifier,
    isDarkTheme: Boolean,
    onThemeToggle: () -> Unit,
    onSpeakTest: (String) -> Unit,
    isExactAlarmGranted: Boolean,
    isOverlayGranted: Boolean,
    isBatteryOptIgnored: Boolean,
    isNotificationPolicyGranted: Boolean,
    isPostNotificationGranted: Boolean,
    onRequestExactAlarm: () -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestBatteryOpt: () -> Unit,
    onRequestNotificationPolicy: () -> Unit,
    onRequestPostNotifications: () -> Unit,
    viewModel: RoutineViewModel = viewModel()
) {
    val context = LocalContext.current
    val routines by viewModel.routines.collectAsStateWithLifecycle()
    val allArmed = isExactAlarmGranted && isOverlayGranted && isBatteryOptIgnored && isNotificationPolicyGranted && isPostNotificationGranted
    
    // Dialog and Modal controls
    var showAddDialog by remember { mutableStateOf(false) }
    var activeEditingRoutine by remember { mutableStateOf<Routine?>(null) }
    var showPermissionsConsole by remember { mutableStateOf(false) }

    // Dynamic Live clock state (12H display)
    var currentSystemTime by remember { mutableStateOf("") }
    var currentSystemDate by remember { mutableStateOf("") }

    // On Startup, if key permissions are missing, show permissions console automatically to explain and help authorize
    LaunchedEffect(Unit) {
        if (!isExactAlarmGranted || !isOverlayGranted || !isBatteryOptIgnored || !isNotificationPolicyGranted || !isPostNotificationGranted) {
            showPermissionsConsole = true
        }
    }

    LaunchedEffect(Unit) {
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val dateFormat = SimpleDateFormat("EEEE, MMMM dd", Locale.getDefault())
        while (true) {
            val now = Calendar.getInstance().time
            currentSystemTime = timeFormat.format(now).uppercase()
            currentSystemDate = dateFormat.format(now)
            delay(1000)
        }
    }

    // Dynamic prediction for next routine announcement
    val nextUpcomingRoutine = remember(routines) {
        val active = routines.filter { it.isAlarmOn }
        if (active.isEmpty()) null
        else {
            val now = Calendar.getInstance()
            val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            active.minByOrNull { r ->
                val rMinutes = r.hour * 60 + r.minute
                val diff = rMinutes - currentMinutes
                if (diff >= 0) diff else (24 * 60) + diff
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = if (isDarkTheme) {
                        listOf(DarkBackgroundStart, DarkBackgroundEnd)
                    } else {
                        listOf(LightBackgroundStart, LightBackgroundEnd)
                    }
                )
            )
    ) {
        // Shifting glowing orbs beneath our glass cards for visual glassmorphism shine
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = size.width * 0.55f
            val cyanGlow = if (isDarkTheme) DarkAccentCyan.copy(alpha = 0.12f) else LightAccentPearl.copy(alpha = 0.20f)
            val purpleGlow = if (isDarkTheme) DarkAccentPurple.copy(alpha = 0.10f) else LightAccentAmber.copy(alpha = 0.15f)
            
            drawCircle(
                brush = Brush.radialGradient(colors = listOf(cyanGlow, Color.Transparent)),
                center = Offset(size.width * 0.15f, size.height * 0.25f),
                radius = radius
            )
            drawCircle(
                brush = Brush.radialGradient(colors = listOf(purpleGlow, Color.Transparent)),
                center = Offset(size.width * 0.85f, size.height * 0.70f),
                radius = radius
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 84.dp)
        ) {
            // HIGH-END ELEGANT HEADER SECTION
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 28.dp, start = 24.dp, end = 24.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "SYSTEM ACTIVE",
                            color = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        if (currentSystemTime.isNotEmpty()) {
                            Text(
                                text = "•  $currentSystemTime",
                                color = if (isDarkTheme) Color.White.copy(alpha = 0.7f) else LightTextPrimary.copy(alpha = 0.6f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Vocal Schedule",
                        color = if (isDarkTheme) Color.White else LightTextPrimary,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = (-0.5).sp
                    )
                }
                
                // Light & Dark mode Toggle + Settings side widgets
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Glass Theme Switcher Box
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isDarkTheme) Color(0x33FFFFFF) else Color(0x1F000000))
                            .clickable { onThemeToggle() },
                        contentAlignment = Alignment.Center
                    ) {
                        ThemeToggleIcon(
                            isDark = isDarkTheme,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // System Exact Alarm Diagnostic Badge
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isDarkTheme) Color(0x33FFFFFF) else Color(0x1F000000))
                            .clickable { showPermissionsConsole = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (allArmed) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = "Check Permissions",
                            tint = if (allArmed) {
                                if (isDarkTheme) DarkAccentCyan else StateActiveGreen
                            } else {
                                StateAlertRose
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // SYSTEM SECURITY WARNING BANNER IF INCOMPLETE
            if (!allArmed) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(StateAlertRose.copy(alpha = 0.15f))
                        .border(BorderStroke(1.dp, StateAlertRose.copy(alpha = 0.4f)), RoundedCornerShape(16.dp))
                        .clickable { showPermissionsConsole = true }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Warning",
                            tint = StateAlertRose,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SYSTEM IS NOT FULLY ARMED",
                                color = StateAlertRose,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Alarms may fail while closed. Grant all permissions.",
                                color = if (isDarkTheme) Color.White.copy(alpha = 0.8f) else LightTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Text(
                            text = "RESOLVE ✓",
                            color = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .border(BorderStroke(1.dp, if (isDarkTheme) DarkAccentCyan.copy(alpha = 0.4f) else LightAccentPearl.copy(alpha = 0.4f)), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // NEXT ANNOUNCEMENT GLASS HERO CARD
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp)
                    .glassCard(isDarkTheme, RoundedCornerShape(28.dp))
                    .padding(24.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "UPCOMING ANNOUNCEMENT",
                            color = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                        
                        // Pulsing Green Indicator Dot for alive background service
                        val infiniteTransition = rememberInfiniteTransition(label = "pulse_effect")
                        val blinkAlpha by infiniteTransition.animateFloat(
                            initialValue = 0.3f,
                            targetValue = 1.0f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1400, easing = LinearEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "blink"
                        )
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(StateActiveGreen.copy(alpha = 0.15f))
                                .border(BorderStroke(1.dp, StateActiveGreen.copy(alpha = 0.3f)), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .alpha(blinkAlpha)
                                    .clip(CircleShape)
                                    .background(StateActiveGreen)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    val timeFormatted = if (nextUpcomingRoutine != null) {
                        val amPm = if (nextUpcomingRoutine.hour < 12) "AM" else "PM"
                        val displayHour = when {
                            nextUpcomingRoutine.hour == 0 -> 12
                            nextUpcomingRoutine.hour > 12 -> nextUpcomingRoutine.hour - 12
                            else -> nextUpcomingRoutine.hour
                        }
                        String.format("%02d:%02d %s", displayHour, nextUpcomingRoutine.minute, amPm)
                    } else {
                        "NO ALARMS"
                    }

                    Text(
                        text = timeFormatted,
                        color = if (isDarkTheme) Color.White else LightTextPrimary,
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isBangla = nextUpcomingRoutine?.title?.any { it in '\u0980'..'\u09FF' } ?: false
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isDarkTheme) DarkAccentCyan.copy(alpha = 0.15f) else LightAccentPearl.copy(alpha = 0.12f)
                                )
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (nextUpcomingRoutine == null) "INACTIVE" else if (isBangla) "BANGLA AUDIO" else "ENGLISH AUDIO",
                                color = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }

                        Text(
                            text = nextUpcomingRoutine?.title ?: "Create new alarms below to start tracking.",
                            color = if (isDarkTheme) DarkTextPrimary else LightTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // SCHEDULER SECTION TAB HEADER
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SCHEDULED ROUTINES",
                    color = if (isDarkTheme) DarkTextMuted else LightTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )

                if (routines.isEmpty()) {
                    Text(
                        text = "ADD STARTERS",
                        color = if (isDarkTheme) DarkAccentPurple else LightAccentPearl,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable {
                                viewModel.addRoutine("Drink Water", 8, 30, true)
                                viewModel.addRoutine("ওষুধ খাওয়ার সময়", 14, 0, true)
                                viewModel.addRoutine("Evening Walk", 18, 15, false)
                            }
                            .border(
                                BorderStroke(1.dp, if (isDarkTheme) DarkAccentPurple.copy(alpha = 0.5f) else LightAccentPearl.copy(alpha = 0.5f)),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // LIST OF ROUTINES (Timeline list)
            if (routines.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 24.dp)
                        .glassCard(isDarkTheme, RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Empty routines placeholder",
                            tint = if (isDarkTheme) DarkTextMuted.copy(alpha = 0.4f) else LightTextMuted.copy(alpha = 0.5f),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "NO ROUTINE TASKS CREATED",
                            color = if (isDarkTheme) Color.White else LightTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap the '+' action button to setup personalized spoken system reminders.",
                            color = if (isDarkTheme) DarkTextMuted else LightTextMuted,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(items = routines, key = { it.id }) { routine ->
                        RoutineListItemCard(
                            routine = routine,
                            isDarkTheme = isDarkTheme,
                            onToggleAlarm = { viewModel.toggleAlarm(routine) },
                            onTestVoice = { onSpeakTest(routine.title) },
                            onEdit = { activeEditingRoutine = routine },
                            onDelete = { viewModel.deleteRoutine(routine) }
                        )
                    }
                }
            }
        }

        // FLOATING GLASS NAVIGATION CONTROL BAR
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            (if (isDarkTheme) DarkBackgroundEnd else LightBackgroundEnd).copy(alpha = 0.9f),
                            if (isDarkTheme) DarkBackgroundEnd else LightBackgroundEnd
                        )
                    )
                )
                .padding(horizontal = 24.dp, vertical = 18.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .glassCard(isDarkTheme, RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { Toast.makeText(context, "System diagnostics are normal.", Toast.LENGTH_SHORT).show() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "info badge",
                            tint = if (isDarkTheme) DarkAccentCyan else LightAccentPearl
                        )
                    }

                    IconButton(
                        onClick = { showPermissionsConsole = true }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "settings integration",
                            tint = (if (isDarkTheme) DarkTextPrimary else LightTextPrimary).copy(alpha = 0.5f)
                        )
                    }
                }

                // Add button positioned seamlessly in our visual Glass row
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                        contentColor = if (isDarkTheme) Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Icon", modifier = Modifier.size(16.dp))
                        Text(text = "Add Alarm", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // ADD NEW DIALOG POPUP
        if (showAddDialog) {
            AddEditModuleDialog(
                isDarkTheme = isDarkTheme,
                onDismiss = { showAddDialog = false },
                onSave = { title, hour, minute, active ->
                    viewModel.addRoutine(title, hour, minute, active)
                    showAddDialog = false
                }
            )
        }

        // EDIT ROUTINE DIALOG POPUP
        activeEditingRoutine?.let { routine ->
            AddEditModuleDialog(
                editingRoutine = routine,
                isDarkTheme = isDarkTheme,
                onDismiss = { activeEditingRoutine = null },
                onSave = { title, hour, minute, active ->
                    viewModel.updateRoutine(
                        routine.copy(
                            title = title,
                            hour = hour,
                            minute = minute,
                            isAlarmOn = active
                        )
                    )
                    activeEditingRoutine = null
                }
            )
        }

        // HIGH PRIORITY FULL SCREEN TRIGGER ACTIVE SYSTEM OVERLAY (Locks on Alarm firing state)
        val activeAlarmTitle by VoiceAlarmState.activeAlarmTitle.collectAsStateWithLifecycle()

        AnimatedVisibility(
            visible = activeAlarmTitle != null,
            enter = fadeIn(animationSpec = tween(500)) + expandVertically(animationSpec = tween(500)),
            exit = fadeOut(animationSpec = tween(500)) + shrinkVertically(animationSpec = tween(500))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.94f))
                    .clickable(enabled = false) {},
                contentAlignment = Alignment.Center
            ) {
                // Pulsing accent warning sphere glow radiating behind the main title
                val infiniteTransition = rememberInfiniteTransition(label = "warning_pulse")
                val glowScale by infiniteTransition.animateFloat(
                    initialValue = 0.85f,
                    targetValue = 1.35f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "glow_scale"
                )
                Box(
                    modifier = Modifier
                        .size(360.dp)
                        .alpha(0.14f)
                        .drawBehind {
                            drawCircle(
                                color = StateAlertRose,
                                radius = size.minDimension / 2 * glowScale
                            )
                        }
                )

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(28.dp)
                ) {
                    Text(
                        text = "ROUTINE ANNOUNCEMENT RUNNING",
                        color = StateAlertRose,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.5.sp
                    )
                    
                    Spacer(modifier = Modifier.height(20.dp))
                    
                    Text(
                        text = activeAlarmTitle ?: "Scheduled Task",
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        lineHeight = 42.sp
                    )
                    
                    Spacer(modifier = Modifier.height(60.dp))
                    
                    // Large premium stop button that immediately kills the vocal foreground service
                    Box(
                        modifier = Modifier
                            .size(170.dp)
                            .clip(CircleShape)
                            .background(StateAlertRose)
                            .border(BorderStroke(4.dp, Color.White.copy(alpha = 0.45f)), CircleShape)
                            .clickable {
                                VoiceAlarmState.activeAlarmTitle.value = null
                                context.stopService(Intent(context, RoutineVoiceService::class.java))
                                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
                                notificationManager?.cancel(999)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "STOP",
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ALARM",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(48.dp))
                    
                    Text(
                        text = "Vocal looping triggers up to 3 minutes automatically.",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        if (showPermissionsConsole) {
            PermissionsConsoleDialog(
                isDarkTheme = isDarkTheme,
                isExactAlarmGranted = isExactAlarmGranted,
                isOverlayGranted = isOverlayGranted,
                isBatteryOptIgnored = isBatteryOptIgnored,
                isNotificationPolicyGranted = isNotificationPolicyGranted,
                isPostNotificationGranted = isPostNotificationGranted,
                onRequestExactAlarm = onRequestExactAlarm,
                onRequestOverlay = onRequestOverlay,
                onRequestBatteryOpt = onRequestBatteryOpt,
                onRequestNotificationPolicy = onRequestNotificationPolicy,
                onRequestPostNotifications = onRequestPostNotifications,
                onDismiss = { showPermissionsConsole = false }
            )
        }
    }
}

@Composable
fun PermissionsConsoleDialog(
    isDarkTheme: Boolean,
    isExactAlarmGranted: Boolean,
    isOverlayGranted: Boolean,
    isBatteryOptIgnored: Boolean,
    isNotificationPolicyGranted: Boolean,
    isPostNotificationGranted: Boolean,
    onRequestExactAlarm: () -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestBatteryOpt: () -> Unit,
    onRequestNotificationPolicy: () -> Unit,
    onRequestPostNotifications: () -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    BorderStroke(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            colors = if (isDarkTheme) {
                                listOf(DarkAccentCyan.copy(alpha = 0.4f), Color.Transparent)
                            } else {
                                listOf(LightAccentPearl.copy(alpha = 0.5f), Color.Transparent)
                            }
                        )
                    ),
                    RoundedCornerShape(26.dp)
                ),
            colors = CardDefaults.cardColors(
                containerColor = if (isDarkTheme) Color(0xFF100D22) else Color(0xFAFFFFFF)
            ),
            shape = RoundedCornerShape(26.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                Text(
                    text = "PERMISSIONS CONSOLE",
                    color = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(18.dp))
                
                // Active count
                val totalCount = 5
                var activeCount = 0
                if (isExactAlarmGranted) activeCount++
                if (isOverlayGranted) activeCount++
                if (isBatteryOptIgnored) activeCount++
                if (isNotificationPolicyGranted) activeCount++
                if (isPostNotificationGranted) activeCount++
                
                Text(
                    text = "Status: $activeCount / $totalCount system hooks authorized",
                    color = if (isDarkTheme) Color.White else LightTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    item {
                        PermissionRowItem(
                            title = "Draw Over Other Apps",
                            desc = "Required to wake up screen with Custom Alarm view while phone is locked.",
                            isGranted = isOverlayGranted,
                            isDarkTheme = isDarkTheme,
                            onRequest = onRequestOverlay
                        )
                    }
                    item {
                        PermissionRowItem(
                            title = "Exact Clock Timing",
                            desc = "Required to hook into Android OS core for precise timing.",
                            isGranted = isExactAlarmGranted,
                            isDarkTheme = isDarkTheme,
                            onRequest = onRequestExactAlarm
                        )
                    }
                    item {
                        PermissionRowItem(
                            title = "Push Notifications",
                            desc = "Required to display alarms and control media player.",
                            isGranted = isPostNotificationGranted,
                            isDarkTheme = isDarkTheme,
                            onRequest = onRequestPostNotifications
                        )
                    }
                    item {
                        PermissionRowItem(
                            title = "Silent Bypass (DND)",
                            desc = "Ensures audio announcements trigger even in silent mode.",
                            isGranted = isNotificationPolicyGranted,
                            isDarkTheme = isDarkTheme,
                            onRequest = onRequestNotificationPolicy
                        )
                    }
                    item {
                        PermissionRowItem(
                            title = "Battery Optimizer Bypass",
                            desc = "Bypasses system sleep restrictions to ensure the service runs.",
                            isGranted = isBatteryOptIgnored,
                            isDarkTheme = isDarkTheme,
                            onRequest = onRequestBatteryOpt
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                        contentColor = if (isDarkTheme) Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Close Console", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun PermissionRowItem(
    title: String,
    desc: String,
    isGranted: Boolean,
    isDarkTheme: Boolean,
    onRequest: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isDarkTheme) Color(0x1A000000) else Color(0x06000000))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = if (isDarkTheme) Color.White else LightTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    color = if (isDarkTheme) DarkTextMuted else LightTextMuted,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            
            if (isGranted) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(StateActiveGreen.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "ARMED ✓",
                        color = StateActiveGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Button(
                    onClick = onRequest,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StateAlertRose.copy(alpha = 0.15f),
                        contentColor = StateAlertRose
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text(
                        text = "GRANT",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun RoutineListItemCard(
    routine: Routine,
    isDarkTheme: Boolean,
    onToggleAlarm: () -> Unit,
    onTestVoice: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isBangla = routine.title.any { it in '\u0980'..'\u09FF' }
    val accentColor = if (routine.isAlarmOn) {
        if (isBangla) DarkAccentPurple else DarkAccentCyan
    } else {
        if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFCBD5E1)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .glassCard(isDarkTheme, RoundedCornerShape(22.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Elegant circle identifier badge
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accentColor.copy(alpha = 0.12f))
                    .border(BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isBangla) "ব" else "EN",
                    color = if (routine.isAlarmOn) (if (isDarkTheme) accentColor else Color.Black) else (if (isDarkTheme) DarkTextMuted else LightTextMuted),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Chore details (AM/PM string format)
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = routine.title,
                    color = if (routine.isAlarmOn) {
                        if (isDarkTheme) DarkTextPrimary else LightTextPrimary
                    } else {
                        (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.7f)
                    },
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(2.dp))

                val amPm = if (routine.hour < 12) "AM" else "PM"
                val displayHour = when {
                    routine.hour == 0 -> 12
                    routine.hour > 12 -> routine.hour - 12
                    else -> routine.hour
                }
                val cleanTime = String.format("%02d:%02d %s", displayHour, routine.minute, amPm)
                val statusLabel = if (routine.isAlarmOn) "Active" else "Disabled"

                Text(
                    text = "$cleanTime • $statusLabel",
                    color = if (isDarkTheme) DarkTextMuted else LightTextMuted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Normal
                )
            }

            // Interactive Actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (routine.isAlarmOn) {
                    IconButton(
                        onClick = onTestVoice,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text("🔊", fontSize = 16.sp)
                    }
                }

                // Smooth M3 Switch
                Switch(
                    checked = routine.isAlarmOn,
                    onCheckedChange = { onToggleAlarm() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = if (isDarkTheme) accentColor else LightAccentPearl,
                        uncheckedThumbColor = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.5f),
                        uncheckedTrackColor = Color.Transparent,
                        uncheckedBorderColor = (if (isDarkTheme) GlassDarkBorder else GlassLightBorder).copy(alpha = 0.5f)
                    )
                )

                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Routine Settings",
                        tint = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp)
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Routine",
                        tint = StateAlertRose.copy(alpha = 0.8f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AddEditModuleDialog(
    editingRoutine: Routine? = null,
    isDarkTheme: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Int, Int, Boolean) -> Unit
) {
    var title by remember { mutableStateOf(editingRoutine?.title ?: "") }
    var isPm by remember { mutableStateOf(editingRoutine?.let { it.hour >= 12 } ?: false) }
    var hour12 by remember { 
        mutableStateOf(
            editingRoutine?.let { 
                val h = it.hour % 12
                if (h == 0) 12 else h
            } ?: 8
        ) 
    }
    
    // Complete Freedom selection: allow exact, 1-minute increment minutes
    var minute by remember { mutableStateOf(editingRoutine?.minute ?: 30) }
    var isAlarmOn by remember { mutableStateOf(editingRoutine?.isAlarmOn ?: true) }

    // Synchronize slider state values with state integers
    var hourSliderValue by remember { mutableStateOf(hour12.toFloat()) }
    var minuteSliderValue by remember { mutableStateOf(minute.toFloat()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    BorderStroke(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            colors = if (isDarkTheme) {
                                listOf(DarkAccentCyan.copy(alpha = 0.4f), Color.Transparent)
                            } else {
                                listOf(LightAccentPearl.copy(alpha = 0.5f), Color.Transparent)
                            }
                        )
                    ),
                    RoundedCornerShape(26.dp)
                ),
            colors = CardDefaults.cardColors(
                containerColor = if (isDarkTheme) Color(0xFF100D22) else Color(0xFAFFFFFF)
            ),
            shape = RoundedCornerShape(26.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                Text(
                    text = if (editingRoutine == null) "CREATE ROUTINE" else "EDIT ROUTINE",
                    color = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Title Section
                Text(
                    text = "TASK DESCRIPTION (ENGLISH / বাংলা)",
                    color = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.8f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { 
                        Text(
                            "Drink water / পানি পান করুন", 
                            color = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.4f),
                            fontSize = 13.sp
                        ) 
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = if (isDarkTheme) DarkTextPrimary else LightTextPrimary,
                        unfocusedTextColor = if (isDarkTheme) DarkTextPrimary else LightTextPrimary,
                        focusedBorderColor = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                        unfocusedBorderColor = if (isDarkTheme) GlassDarkBorder else GlassLightBorder,
                        cursorColor = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                        focusedContainerColor = if (isDarkTheme) Color(0xFF0A0718) else Color(0xFFF1F5F9),
                        unfocusedContainerColor = if (isDarkTheme) Color(0xFF0A0718) else Color(0xFFF1F5F9)
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )

                // Quick Shortcuts
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val shortcuts = listOf("Water 💧", "ব্যায়াম 🧘", "Walk 🚶")
                    shortcuts.forEach { label ->
                        val plainText = label.replace(Regex("[\\uD83C-\\uDBFF\\uDC00-\\uDFFF]"), "").trim()
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isDarkTheme) Color(0x1FBD00FF) else Color(0x1F6366F1))
                                .clickable { title = label }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = label,
                                color = if (isDarkTheme) DarkAccentPurple else LightAccentPearl,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Time Pickers (Tops: Buttons, Bottoms: Linear continuous precision sliders, 1-minute increments)
                Text(
                    text = "TIME OF TRIGGER (1-MINUTE INCREMENTS)",
                    color = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.8f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isDarkTheme) Color(0xFF090616) else Color(0xFFEFF3F8), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Hour Spinner Layout
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = { 
                                hour12 = if (hour12 == 12) 1 else hour12 + 1 
                                hourSliderValue = hour12.toFloat()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.KeyboardArrowUp, contentDescription = "", tint = if (isDarkTheme) DarkAccentCyan else LightAccentPearl)
                        }
                        
                        Text(
                            text = String.format("%02d", hour12),
                            color = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )

                        IconButton(
                            onClick = { 
                                hour12 = if (hour12 == 1) 12 else hour12 - 1 
                                hourSliderValue = hour12.toFloat()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "", tint = if (isDarkTheme) DarkAccentCyan else LightAccentPearl)
                        }
                        Text("HOURS", fontSize = 8.sp, color = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.6f), fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = ":",
                        color = if (isDarkTheme) DarkTextPrimary else LightTextPrimary,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    // Minute Spinner Layout (1-minute accuracy)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = { 
                                minute = (minute + 1) % 60
                                minuteSliderValue = minute.toFloat()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.KeyboardArrowUp, contentDescription = "", tint = if (isDarkTheme) DarkAccentCyan else LightAccentPearl)
                        }

                        Text(
                            text = String.format("%02d", minute),
                            color = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )

                        IconButton(
                            onClick = { 
                                minute = if (minute == 0) 59 else minute - 1
                                minuteSliderValue = minute.toFloat()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "", tint = if (isDarkTheme) DarkAccentCyan else LightAccentPearl)
                        }
                        Text("MINUTES", fontSize = 8.sp, color = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.6f), fontWeight = FontWeight.Bold)
                    }

                    // AM / PM choice matrix box
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(start = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (!isPm) (if (isDarkTheme) DarkAccentCyan else LightAccentPearl) else Color.Transparent)
                                .border(BorderStroke(1.dp, if (!isPm) Color.Transparent else (if (isDarkTheme) GlassDarkBorder else GlassLightBorder)), RoundedCornerShape(8.dp))
                                .clickable { isPm = false }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "AM",
                                color = if (!isPm) Color.Black else (if (isDarkTheme) DarkTextMuted else LightTextMuted),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isPm) (if (isDarkTheme) DarkAccentCyan else LightAccentPearl) else Color.Transparent)
                                .border(BorderStroke(1.dp, if (isPm) Color.Transparent else (if (isDarkTheme) GlassDarkBorder else GlassLightBorder)), RoundedCornerShape(8.dp))
                                .clickable { isPm = true }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "PM",
                                color = if (isPm) Color.Black else (if (isDarkTheme) DarkTextMuted else LightTextMuted),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // LINEAR FINE TUNING SLIDERS FOR ABSOLUTE FREEDOM
                Spacer(modifier = Modifier.height(14.dp))
                
                Text(
                    text = "Slide to adjust Minute precisely (1m increments)",
                    color = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = minuteSliderValue,
                    onValueChange = { 
                        minuteSliderValue = it
                        minute = it.toInt()
                    },
                    valueRange = 0f..59f,
                    colors = SliderDefaults.colors(
                        thumbColor = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                        activeTrackColor = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                        inactiveTrackColor = (if (isDarkTheme) GlassDarkBorder else GlassLightBorder).copy(alpha = 0.3f)
                    )
                )

                Text(
                    text = "Slide to adjust Hour precisely (1h increments)",
                    color = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = hourSliderValue,
                    onValueChange = { 
                        hourSliderValue = it
                        hour12 = it.toInt()
                    },
                    valueRange = 1f..12f,
                    colors = SliderDefaults.colors(
                        thumbColor = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                        activeTrackColor = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                        inactiveTrackColor = (if (isDarkTheme) GlassDarkBorder else GlassLightBorder).copy(alpha = 0.3f)
                    )
                )

                // STATE OF ALARM SWITCH ROW
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACTIVATED AND RUNNING",
                        color = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.8f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Switch(
                        checked = isAlarmOn,
                        onCheckedChange = { isAlarmOn = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = StateActiveGreen,
                            uncheckedThumbColor = (if (isDarkTheme) DarkTextMuted else LightTextMuted).copy(alpha = 0.5f),
                            uncheckedTrackColor = Color.Transparent,
                            uncheckedBorderColor = if (isDarkTheme) GlassDarkBorder else GlassLightBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Standard, clear controls avoiding sci-fi slogans
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = StateAlertRose
                        ),
                        border = BorderStroke(1.dp, if (isDarkTheme) GlassDarkBorder else GlassLightBorder),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Cancel",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            val cleanTitle = title.trim().ifEmpty { "Daily Routine" }
                            val finalHour = when {
                                isPm && hour12 < 12 -> hour12 + 12
                                !isPm && hour12 == 12 -> 0
                                else -> hour12
                            }
                            onSave(cleanTitle, finalHour, minute, isAlarmOn)
                        },
                        modifier = Modifier
                            .weight(1.4f)
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDarkTheme) DarkAccentCyan else LightAccentPearl,
                            contentColor = if (isDarkTheme) Color.Black else Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Set Alarm",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
