package com.example.data

import kotlinx.coroutines.flow.Flow

class RoutineRepository(private val routineDao: RoutineDao) {
    val allRoutines: Flow<List<Routine>> = routineDao.getAllRoutines()

    suspend fun getRoutineById(id: Int): Routine? = routineDao.getRoutineById(id)

    suspend fun getActiveRoutines(): List<Routine> = routineDao.getActiveRoutines()

    suspend fun insert(routine: Routine): Long = routineDao.insertRoutine(routine)

    suspend fun update(routine: Routine) = routineDao.updateRoutine(routine)

    suspend fun delete(routine: Routine) = routineDao.deleteRoutine(routine)
}
