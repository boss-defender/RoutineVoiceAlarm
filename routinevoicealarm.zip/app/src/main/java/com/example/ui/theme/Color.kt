package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme - "Liquid Pearl" Glassmorphic color tokens
val GlassLightBg = Color(0x4DFFFFFF)        // Frosted semi-transparent white (30% alpha for great glass see-through)
val GlassLightBorder = Color(0xB3FFFFFF)    // Glossy glowing white border reflection
val LightBackgroundStart = Color(0xFFFFECE5) // Shifting Peach Sand glow
val LightBackgroundCenter = Color(0xFFEDF2FB) // Clear Frosty Blue sky
val LightBackgroundEnd = Color(0xFFE2EAFC)   // Cool lilac mist
val LightTextPrimary = Color(0xFF0F172A)     // Dark Obsidian slate for high contrast
val LightTextMuted = Color(0xFF475569)       // Deep charcoal grey for readable labels
val LightAccentPearl = Color(0xFF6366F1)     // Indigo Blue highlight
val LightAccentAmber = Color(0xFFF59E0B)     // Warm Amber glow

// Dark Theme - "Cosmic Obsidian" Glassmorphic color tokens
val GlassDarkBg = Color(0x1F121224)         // Translucent dark space slate with deep alpha
val GlassDarkBorder = Color(0x2BFFFFFF)     // Brushed silver-steel border reflection
val DarkBackgroundStart = Color(0xFF080415)  // Near Black obsidian base
val DarkBackgroundCenter = Color(0xFF0F0A26) // Deep stellar indigo
val DarkBackgroundEnd = Color(0xFF040209)    // True outer-space black void
val DarkTextPrimary = Color(0xFFF8FAFC)      // Radiant smooth silver slate
val DarkTextMuted = Color(0xFF94A3B8)        // Steel slate gray
val DarkAccentCyan = Color(0xFF00F0FF)       // Signature Vibrant Neon Cyan
val DarkAccentPurple = Color(0xFFBD00FF)     // Deep Vivid Neon Purple

// General active states
val StateActiveGreen = Color(0xFF10B981)     // Energetic success mint
val StateAlertRose = Color(0xFFF43F5E)       // Hot Vibrant warning rose
