package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = DarkAccentCyan,
    secondary = DarkAccentPurple,
    tertiary = StateActiveGreen,
    background = DarkBackgroundStart,
    surface = GlassDarkBg,
    onBackground = DarkTextMuted,
    onSurface = DarkTextPrimary,
    primaryContainer = Color(0xFF120E2B),
    onPrimaryContainer = DarkAccentCyan,
    secondaryContainer = Color(0x1FBD00FF),
    onSecondaryContainer = DarkAccentPurple
)

private val LightColorScheme = lightColorScheme(
    primary = LightAccentPearl,
    secondary = LightAccentAmber,
    tertiary = StateActiveGreen,
    background = LightBackgroundCenter,
    surface = GlassLightBg,
    onBackground = LightTextMuted,
    onSurface = LightTextPrimary,
    primaryContainer = Color(0xFFEFF0FE),
    onPrimaryContainer = LightAccentPearl,
    secondaryContainer = Color(0x1F6366F1),
    onSecondaryContainer = LightAccentAmber
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
