package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.alarm.AlarmScheduler
import com.example.data.AppDatabase
import com.example.data.Routine
import com.example.data.RoutineRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RoutineViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: RoutineRepository
    private val alarmScheduler = AlarmScheduler(application)

    val routines: StateFlow<List<Routine>>

    init {
        val routineDao = AppDatabase.getDatabase(application).routineDao()
        repository = RoutineRepository(routineDao)
        routines = repository.allRoutines.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun addRoutine(title: String, hour: Int, minute: Int, isAlarmOn: Boolean) {
        viewModelScope.launch {
            val routine = Routine(
                title = title,
                hour = hour,
                minute = minute,
                isAlarmOn = isAlarmOn
            )
            val newId = repository.insert(routine)
            if (isAlarmOn) {
                alarmScheduler.schedule(routine.copy(id = newId.toInt()))
            }
        }
    }

    fun updateRoutine(routine: Routine) {
        viewModelScope.launch {
            repository.update(routine)
            if (routine.isAlarmOn) {
                alarmScheduler.schedule(routine)
            } else {
                alarmScheduler.cancel(routine)
            }
        }
    }

    fun deleteRoutine(routine: Routine) {
        viewModelScope.launch {
            alarmScheduler.cancel(routine)
            repository.delete(routine)
        }
    }

    fun toggleAlarm(routine: Routine) {
        val updated = routine.copy(isAlarmOn = !routine.isAlarmOn)
        updateRoutine(updated)
    }
}
