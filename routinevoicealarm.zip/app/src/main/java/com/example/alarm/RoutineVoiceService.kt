package com.example.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow

object VoiceAlarmState {
    val activeAlarmTitle = MutableStateFlow<String?>(null)
}

class RoutineVoiceService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private var titleToSpeak: String = ""

    override fun onCreate() {
        super.onCreate()
        Log.d("RoutineVoiceService", "Foreground Keep-Alive Service created")
        
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "RoutineVoice::WakelockTag"
        ).apply {
            acquire(4 * 60 * 1000L) // Holds wake lock for max 4 minutes
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val routineTitle = intent?.getStringExtra("ROUTINE_TITLE") ?: "Routine Task"
        titleToSpeak = routineTitle
        Log.d("RoutineVoiceService", "Foreground Keep-Alive service active for: $routineTitle")

        // Expose alarm status to UI via global VoiceAlarmState
        VoiceAlarmState.activeAlarmTitle.value = titleToSpeak

        showNotification(routineTitle)
        return START_NOT_STICKY
    }

    private fun showNotification(routineTitle: String) {
        val channelId = "routine_voice_alarms"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Routine Voice Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Vocal announcements for RoutineVoice"
                enableVibration(true)
                setBypassDnd(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Setup clear intent to open MainActivity in alarm mode
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("ALARM_TRIGGERED", true)
            putExtra("ROUTINE_TITLE", routineTitle)
        }
        val finalPendingFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            finalPendingFlags
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Active Routine Announcement")
            .setContentText(routineTitle)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pendingIntent, true) // Force full-screen lock screen intent!
            .setAutoCancel(false)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(999, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(999, notification)
        }
    }

    override fun onDestroy() {
        Log.d("RoutineVoiceService", "Service onDestroy - cleaning up keepalive")
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        VoiceAlarmState.activeAlarmTitle.value = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
