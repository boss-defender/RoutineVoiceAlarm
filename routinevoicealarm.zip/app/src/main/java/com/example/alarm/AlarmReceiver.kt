package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.MainActivity
import com.example.data.AppDatabase
import com.example.data.RoutineRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val routineId = intent.getIntExtra("ROUTINE_ID", -1)
        val routineTitle = intent.getStringExtra("ROUTINE_TITLE") ?: "Routine Task"
        Log.d("AlarmReceiver", "Received alarm: $routineTitle (ID: $routineId)")

        val serviceIntent = Intent(context, RoutineVoiceService::class.java).apply {
            putExtra("ROUTINE_TITLE", routineTitle)
        }

        // 1. Immediately launch MainActivity with alarm triggered flags to force wake-up and run TTS in foreground
        val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("ALARM_TRIGGERED", true)
            putExtra("ROUTINE_TITLE", routineTitle)
        }

        try {
            context.startActivity(fullScreenIntent)
            Log.d("AlarmReceiver", "Directly started MainActivity for routine title: $routineTitle")
        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Could not start MainActivity directly, relying on full screen intent notification", e)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Failed to start service directly, attempting regular start", e)
            try {
                context.startService(serviceIntent)
            } catch (ex: Exception) {
                Log.e("AlarmReceiver", "Failed to start RoutineVoiceService completely", ex)
            }
        }

        // Fetch our database repository and reschedule this routine for tomorrow
        val db = AppDatabase.getDatabase(context.applicationContext)
        val repository = RoutineRepository(db.routineDao())
        val pendingResult = goAsync()
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (routineId != -1) {
                    val routine = repository.getRoutineById(routineId)
                    if (routine != null && routine.isAlarmOn) {
                        val scheduler = AlarmScheduler(context.applicationContext)
                        scheduler.schedule(routine)
                        Log.d("AlarmReceiver", "Rescheduled routine: ${routine.title} daily")
                    }
                }
            } catch (e: Exception) {
                Log.e("AlarmReceiver", "Err in rescheduling task", e)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
