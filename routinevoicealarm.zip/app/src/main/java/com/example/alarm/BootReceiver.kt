package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.RoutineRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || 
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            Log.d("BootReceiver", "Boot completed event received. Scheduling active routine alarms...")
            
            val pendingResult = goAsync()
            val db = AppDatabase.getDatabase(context.applicationContext)
            val repository = RoutineRepository(db.routineDao())
            val scheduler = AlarmScheduler(context.applicationContext)
            
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val activeRoutines = repository.getActiveRoutines()
                    for (routine in activeRoutines) {
                        scheduler.schedule(routine)
                        Log.d("BootReceiver", "Rescheduled routine: ${routine.title}")
                    }
                } catch (e: Exception) {
                    Log.e("BootReceiver", "Failed to reschedule on system boot", e)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
